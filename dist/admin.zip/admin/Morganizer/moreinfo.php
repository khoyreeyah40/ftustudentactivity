<?php

	error_reporting( ~E_NOTICE );
	
	$DB_HOST = 'localhost';
	$DB_USER = 'root';
	$DB_PASS = '';
	$DB_NAME = 'dbmyproject';
	
	try{
		$DB_con = new PDO("mysql:host={$DB_HOST};dbname={$DB_NAME}",$DB_USER,$DB_PASS);
		$DB_con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
	catch(PDOException $e){
		echo $e->getMessage();
	}
	
	if(isset($_POST['id']))
	{
        $id = $_POST['id'];
        $stmt_view = $DB_con->prepare('SELECT orgzerID,orgzerName,orgzeruserType,orgzerGroup,orgzerOrgtion,orgzerOffice,orgzerPhone,orgzerEmail,orgzerFb,orgzerPassword,orgzerAddby, createat, orgzerImage FROM organizer WHERE orgzerID=:id');
		$stmt_view->execute(array(':id'=>$id));
		$view_row = $stmt_view->fetch(PDO::FETCH_ASSOC);
		extract($view_row);
	}
?>
                                        <div class="card-body">
                                            <div class="row mt-2">
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label>รหัสนักศึกษา</label>
                                                      <input type="text" class="form-control"name="orgzerID" value="<?php echo $orgzerID;?>" readonly>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label>ชื่อ-สกุล</label>
                                                        <input type="text" class="form-control"name="orgzerName" value="<?php echo $orgzerName;?>" readonly>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mt-2">
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label>สถานะ</label>
                                                      <select class="form-control" style="width: 100%;" name="orgzeruserType" readonly>
                                                        <option> <?php echo $orgzeruserType; ?></option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label>กลุ่ม</label>
                                                      <select class="form-control" style="width: 100%;" name="orgzerGroup" readonly>
                                                        <option> <?php echo $orgzerGroup; ?></option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mt-2">
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label>คณะ/หน่วยงาน/องค์กร</label>
                                                      <select class="form-control" style="width: 100%;" name="orgzerOrgtion" readonly>
                                                        <option> <?php echo $orgzerOrgtion; ?></option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label>ชมรม/ชุมนุม/สาขา/อื่นๆ</label>
                                                      <select class="form-control" style="width: 100%;" name="orgzerOffice" readonly>
                                                        <option> <?php echo $orgzerOffice; ?></option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mt-2">
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label>หมายเลขโทรศัพท์</label>
                                                      <input type="text" class="form-control" name="orgzerPhone" value="<?php echo $orgzerPhone; ?>" readonly/>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label>Email</label>
                                                      <input type="text" class="form-control" name="orgzerEmail" value="<?php echo $orgzerEmail; ?>" readonly/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mt-2">
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label>Facebook</label>
                                                      <input type="text" class="form-control" name="orgzerFb" value="<?php echo $orgzerFb; ?>" readonly/>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label>Password</label>
                                                      <input type="text" class="form-control" name="orgzerPassword" value="<?php echo $orgzerPassword; ?>" readonly/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mt-2">
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label>เพิ่มโดย</label>
                                                      <input type="text" class="form-control" name="orgzerAddby" value="<?php echo $orgzerAddby; ?>" readonly/>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label>เพิ่มวันที่</label>
                                                      <input type="text" class="form-control"  name="createat" value="<?php echo $createat; ?>" readonly/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mt-2">
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label>รูปประจำตัว</label>
                                                      <img src="../../assets/img/profile/value="<?php echo $orgzerImage; ?>"" align="center" class="img-rounded" width="220px" height="200px" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


