<?php

	error_reporting( ~E_NOTICE );


	$DB_HOST = 'localhost';
	$DB_USER = 'root';
	$DB_PASS = '';
	$DB_NAME = 'dbmyproject';
	
	try{
		$DB_con = new PDO("mysql:host={$DB_HOST};dbname={$DB_NAME}",$DB_USER,$DB_PASS);
		$DB_con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
	catch(PDOException $e){
		echo $e->getMessage();
	}
	if(isset($_GET['update_id']) && !empty($_GET['update_id']))
	{
        $id = $_GET['update_id'];
        $stmt_update = $DB_con->prepare('SELECT orgzerID,orgzerName,orgzeruserType,orgzerGroup,orgzerOrgtion,orgzerOffice,orgzerPhone,orgzerEmail,orgzerFb,orgzerPassword,orgzerAddby, createat FROM organizer WHERE orgzerID=:orgzerid');
		$stmt_update->execute(array(':orgzerid'=>$id));
		$update_row = $stmt_update->fetch(PDO::FETCH_ASSOC);
		extract($update_row);
    }
    else
	{
		header("Location: organizer.php");
    }
    if(isset($_POST['btupdateorgzer']))
    {	
      $orgzerID = $_POST['orgzerID'];
      $orgzerName = $_POST['orgzerName'];// user name
      $orgzeruserType = $_POST['orgzeruserType'];
      $orgzerGroup = $_POST['orgzerGroup'];
      $orgzerOrgtion = $_POST['orgzerOrgtion'];
      $orgzerOffice = $_POST['orgzerOffice'];
      $orgzerPhone = $_POST['orgzerPhone'];
      $orgzerEmail = $_POST['orgzerEmail'];
      $orgzerFb = $_POST['orgzerFb'];
      $orgzerPassword = $_POST['orgzerPassword']; 
      $orgzerAddby = $_POST['orgzerAddby']; 
        // if no error occured, continue ....
        if(!isset($errMSG))
        {
          $stmt = $DB_con->prepare('UPDATE organizer
                                    SET orgzerID=:orgzerID,
                                    orgzerName=:orgzerName,
                                    orgzeruserType=:orgzeruserType,
                                    orgzerGroup=:orgzerGroup,
                                    orgzerOrgtion=:orgzerOrgtion,
                                    orgzerOffice=:orgzerOffice,
                                    orgzerPhone=:orgzerPhone,
                                    orgzerEmail=:orgzerEmail,
                                    orgzerFb=:orgzerFb,
                                    orgzerPassword=:orgzerPassword,
                                    orgzerAddby=:orgzerAddby
                                    WHERE orgzerID=:orgzerID');
          $stmt->bindParam(':orgzerID',$orgzerID);
          $stmt->bindParam(':orgzerName',$orgzerName);
          $stmt->bindParam(':orgzeruserType',$orgzeruserType);
          $stmt->bindParam(':orgzerGroup',$orgzerGroup);
          $stmt->bindParam(':orgzerOrgtion',$orgzerOrgtion);
          $stmt->bindParam(':orgzerOffice',$orgzerOffice);
          $stmt->bindParam(':orgzerPhone',$orgzerPhone);
          $stmt->bindParam(':orgzerEmail',$orgzerEmail);
          $stmt->bindParam(':orgzerFb',$orgzerFb);
          $stmt->bindParam(':orgzerPassword',$orgzerPassword);
          $stmt->bindParam(':orgzerAddby',$orgzerAddby);
          if($stmt->execute()){
            ?>
            <script>
            alert('ทำการแก้ไขเรียบร้อย ...');
            window.location.href='organizer.php';
            </script>
            <?php
          }
          else
          {
            $errMSG = "พบข้อผิดพลาด";
          }
        }
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title>ระบบกิจกรรมนักศึกษา| จัดการผู้ใช้</title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="../../assets/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../../assets/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
    <link href="../../assets/vendors/themify-icons/css/themify-icons.css" rel="stylesheet" />
    <!-- PLUGINS STYLES-->
    <link href="../../assets/vendors/select2/dist/css/select2.min.css" rel="stylesheet" />
    <link href="../../assets/vendors/DataTables/datatables.min.css" rel="stylesheet" />
    <link href="../../assets/vendors/jvectormap/jquery-jvectormap-2.0.3.css" rel="stylesheet" />
    <!-- THEME STYLES-->
    <link href="../../assets/css/main.min.css" rel="stylesheet" />
    <!-- PAGE LEVEL STYLES-->
    <style>
      .breadcrumb-item {
        font-size:16px;
        }
    </style>
</head>
<body class="fixed-navbar" style="background-color:#f3e9d2;">
            <div class="page-content fade-in-up"style="padding:20px;padding-top:0px">
                <div class="page-heading">
                    <h1 class="page-title">จัดการผู้จัดกิจกรรม</h1>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                        </li>
                        <li class="breadcrumb-item"><a href="organizer.php">จัดการผู้จัดกิจกรรม</a></li>
                        <li class="breadcrumb-item">แก้ไขข้อมูลผู้จัดกิจกรรม</li>
                    </ol>
                </div>
                <br>
                <br> 
                <?php
	if(isset($errMSG)){
		?>
        <div class="alert alert-danger">
          <span class="fa fa-info-sign"></span> &nbsp; <?php echo $errMSG; ?>
        </div>
        <?php
	}
	?>
                    <div class="ibox">
                        <div class="ibox-head" style="background-color:#2a9d8f">
                            <div class="ibox-title" style="color:white"><h5>แก้ไขข้อมูลผู้จัดกิจกรรม</h5></div>
                        </div>
                        <div class="ibox-body">
                            <form class="form-horizontal" id="form-sample-1"  method="post" novalidate="novalidate" style="height:500px; width:100%">
                                
                            <div class="form-group row">
                                    <label class="col-sm-1 col-form-label">รหัสผู้ใช้</label>
                                    <div class="col-sm-5">
                                        <input class="form-control" type="text" name="orgzerID" value="<?php echo $orgzerID; ?>" readonly/>
                                    </div>
                                    <label class="col-sm-1 col-form-label">ชื่อ-สกุล</label>
                                    <div class="col-sm-5">
                                        <input class="form-control" type="text" name="orgzerName" value="<?php echo $orgzerName; ?>" required />
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-1 col-form-label">สถานะ</label>
                                    <div class="col-sm-5">
                                        <select class="form-control" style="width: 100%;" name="orgzeruserType" >
                                        <option value="<?php echo $orgzeruserType ?>"> <?php echo $orgzeruserType ?></option>                                   
                                        <?php
                                        include '../../db/dbcon.php';
                                        $sql = "SELECT userType FROM usertype";
                                        $result = $conn->query($sql);
                                        
                                            if ($result->num_rows > 0){
                                            while($row = $result->fetch_assoc()){
                                                $userTypelist = $row["userType"];
                                        ?>
                                                <option value="<?php echo $userTypelist ?>"> <?php echo $userTypelist ?></option>
                                        <?php
                                                }
                                            }else{
                                                    echo "something";
                                            }
                                        ?>
                                        </select>
                                    </div>
                                    <label class="col-sm-1 col-form-label">กลุ่ม</label>
                                    <div class="col-sm-5">
                                        <select class="form-control" style="width: 100%;" name="orgzerGroup"required >
                                            <option value="<?php echo $orgzerGroup ?>"> <?php echo $orgzerGroup ?></option>
                                            <option value="ชาย">ชาย</option>
                                            <option value="หญิง">หญิง</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-1 col-form-label">องค์กร</label>
                                    <div class="col-sm-5">
                                        <select class="form-control" style="width: 100%;" name="orgzerOrgtion"required >
                                        <option value="<?php echo $orgzerOrgtion ?>"> <?php echo $orgzerOrgtion ?></option>
                                        <?php
                                        include '../../db/dbcon.php';
                                        $sql = "SELECT organization FROM organization";
                                        $result = $conn->query($sql);
                                        
                                            if ($result->num_rows > 0){
                                            while($row = $result->fetch_assoc()){
                                                $organizationlist = $row["organization"];
                                        ?>
                                                <option value="<?php echo $organizationlist ?>"> <?php echo $organizationlist ?></option>
                                        <?php
                                                }
                                            }else{
                                                    echo "something";
                                            }
                                        ?>
                                        </select>
                                    </div>
                                    <label class="col-sm-1 col-form-label">สังกัด</label>
                                    <div class="col-sm-5">
                                        <select class="form-control select2_demo_1" style="width: 100%;" name="orgzerOffice">
                                        <option value="<?php echo $orgzerOffice ?>"> <?php echo $orgzerOffice ?></option>
                                            <?php
                                            include '../../db/dbcon.php';
                                            $sql = "SELECT office FROM office";
                                            $result = $conn->query($sql);
                                            
                                                if ($result->num_rows > 0){
                                                while($row = $result->fetch_assoc()){
                                                    $officelist = $row["office"];
                                            ?>
                                                    <option value="<?php echo $officelist ?>"> <?php echo $officelist ?></option>
                                            <?php
                                                    }
                                                }else{
                                                        echo "something";
                                                }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-1 col-form-label">เบอร์โทร</label>
                                    <div class="col-sm-5">
                                        <input class="form-control" id="ex-phone" type="text" name="orgzerPhone" value="<?php echo $orgzerPhone; ?>"  required />
                                    </div>
                                    <label class="col-sm-1 col-form-label">E-mail</label>
                                    <div class="col-sm-5">
                                        <input class="form-control" type="text" name="orgzerEmail" value="<?php echo $orgzerEmail; ?>"  required />
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-1 col-form-label">Facebook</label>
                                    <div class="col-sm-5">
                                        <input class="form-control" type="text" name="orgzerFb" value="<?php echo $orgzerFb; ?>"  required />
                                    </div>
                                    <label class="col-sm-1 col-form-label">รหัสผ่าน</label>
                                    <div class="col-sm-5">
                                        <input class="form-control" id="password" type="password" name="orgzerPassword" placeholder="password" value="<?php echo $orgzerPassword; ?>" required />
                                    </div>
                                </div>
                                <div class="form-group row">
                                    
                                    <label class="col-sm-1 col-form-label">เพิ่มโดย</label>
                                    <div class="col-sm-5">
                                        <input class="form-control" type="text" name="orgzerAddby" value="<?php echo $orgzerAddby;?>"  readonly/>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12 text-center">
                                        <button class="btn btn-info" type="submit" name="btupdateorgzer">แก้ไข</button>
                                        <button class="btn btn-danger" type="button"><a href="organizer.php">ยกเลิก</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
            </div>
                    
    <!-- CORE PLUGINS-->
    <script src="../../assets/vendors/jquery/dist/jquery.min.js" type="text/javascript"></script>
    <script src="../../assets/vendors/popper.js/dist/umd/popper.min.js" type="text/javascript"></script>
    <script src="../../assets/vendors/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="../../assets/vendors/metisMenu/dist/metisMenu.min.js" type="text/javascript"></script>
    <script src="../../assets/vendors/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- PAGE LEVEL PLUGINS-->
    <script src=".../../assets/vendors/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
    <script src="../../assets/vendors/jquery.maskedinput/dist/jquery.maskedinput.min.js" type="text/javascript"></script>
    <script src="../../assets/vendors/jquery-validation/dist/jquery.validate.min.js" type="text/javascript"></script>
    <script src="../../assets/vendors/DataTables/datatables.min.js" type="text/javascript"></script>
    <!-- CORE SCRIPTS-->
    <script src="../../assets/js/app.min.js" type="text/javascript"></script>
    <!-- PAGE LEVEL SCRIPTS-->
    <script src="../../assets/js/scripts/form-plugins.js" type="text/javascript"></script>
    <script type="text/javascript">
    
        $(function() {
            $('#tborganizer').DataTable({
                pageLength: 10,
                //"ajax": './assets/demo/data/table_data.json',
                /*"columns": [
                    { "data": "name" },
                    { "data": "office" },
                    { "data": "extn" },
                    { "data": "start_date" },
                    { "data": "salary" }
                ]*/
            });
        })
        $('#ex-phone').mask('(999) 999-9999');
        $("#form-sample-1").validate({
            rules: {
                name: {
                    minlength: 2,
                    required: !0
                },
                email: {
                    required: !0,
                    email: !0
                },
                url: {
                    required: !0,
                    url: !0
                },
                number: {
                    required: !0,
                    number: !0
                },
                min: {
                    required: !0,
                    minlength: 3
                },
                max: {
                    required: !0,
                    maxlength: 4
                },
                password: {
                    required: !0
                },
                password_confirmation: {
                    required: !0,
                    equalTo: "#password"
                }
            },
            errorClass: "help-block error",
            highlight: function(e) {
                $(e).closest(".form-group.row").addClass("has-error")
            },
            unhighlight: function(e) {
                $(e).closest(".form-group.row").removeClass("has-error")
            },
        });

    </script>
    </body>

</html>


