<?php
    require_once("../class/session.php");
    
    require_once("../class/class.organizer.php");
    $auth_orgzer = new ORGANIZER();
     
    $orgzerID = $_SESSION['orgzer_session'];
    
    $stmt = $auth_orgzer->runQuery("SELECT * FROM organizer WHERE orgzerID=:orgzerID");
    $stmt->execute(array(":orgzerID"=>$orgzerID));
    
    $orgzerRow=$stmt->fetch(PDO::FETCH_ASSOC);
?>

<?php
  error_reporting( ~E_NOTICE ); // avoid notice
  require_once 'dbconfig.php';

  if(isset($_POST['btaddposition']))
    {	
      $pstYear = $_POST['pstYear'];
      $pstName = $_POST['pstName'];// user name
      $position = $_POST['position'];
      $pstPhone = $_POST['pstPhone'];
      $pstOrgtion = $_POST['pstOrgtion'];
      $pstOffice = $_POST['pstOffice'];
      $pstAddby = $_POST['pstAddby'];
        // if no error occured, continue ....
        if(!isset($errMSG))
        {
          $stmt = $DB_con->prepare('INSERT INTO member(pstYear,pstName,position,pstPhone,pstOrgtion,pstOffice,pstAddby) VALUES
                                                        (:pstYear,:pstName,:position,:pstPhone,:pstOrgtion,:pstOffice,:pstAddby)');
          $stmt->bindParam(':pstYear',$pstYear);
          $stmt->bindParam(':pstName',$pstName);
          $stmt->bindParam(':position',$position);
          $stmt->bindParam(':pstPhone',$pstPhone);
          $stmt->bindParam(':pstOrgtion',$pstOrgtion);
          $stmt->bindParam(':pstOffice',$pstOffice);
          $stmt->bindParam(':pstAddby',$pstAddby);
          if($stmt->execute())
          {
            $successMSG = "ได้ทำการเพิ่มสำเร็จ";
            header("refresh:2;position.php"); 
          }
          else
          {
            $errMSG = "พบข้อผิดพลาด";
          }
        }
    }
?>

<?php
  require_once '../../db/dbconfig.php';
  if(isset($_GET['delete_id']))
  {
    // it will delete an actual record from db
    $stmt_delete = $DBcon->prepare('DELETE FROM member WHERE pstID =:pstID');
    $stmt_delete->bindParam(':pstID',$_GET['delete_id']);
    $stmt_delete->execute();
   
    header("Location: position.php");
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title>ระบบกิจกรรมนักศึกษา| จัดการตำแหน่งนักศึกษา</title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="../../assets/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../../assets/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
    <link href="../../assets/vendors/themify-icons/css/themify-icons.css" rel="stylesheet" />
    <!-- PLUGINS STYLES-->
    <link href="../../assets/vendors/DataTables/datatables.min.css" rel="stylesheet" />
    <link href="../../assets/vendors/jvectormap/jquery-jvectormap-2.0.3.css" rel="stylesheet" />
    <!-- THEME STYLES-->
    <link href="../../assets/css/main.min.css" rel="stylesheet" />
    <!-- PAGE LEVEL STYLES-->
    <style>
      .breadcrumb-item {
        font-size:16px;
        }
    </style>
</head>
<body class="fixed-navbar" style="background-color:#f3e9d2;">

            <!-- Main content -->
    
            <div class="page-content fade-in-up"style="padding:20px;padding-top:0px">
            <div class="page-heading">
                <h1 class="page-title">จัดการตำแหน่งนักศึกษา</h1>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                    </li>
                    <li class="breadcrumb-item">จัดการตำแหน่งนักศึกษา</li>
                </ol>
            </div>
            <br>
            <br>
            <?php
              if(isset($errMSG)){
            ?>
                <div class="alert alert-danger alert-bordered">
                  <span class="fa fa-info-sign"></span> <strong><?php echo $errMSG; ?></strong>
                </div>
            <?php
              }
              else if(isset($successMSG)){
            ?>
                <div class="alert alert-success alert-bordered">
                  <strong><span class="fa fa-info-sign"></span> <?php echo $successMSG; ?> </strong>
                </div>
            <?php
              }
            ?> 
                <div class="ibox">
                    <div class="ibox-head" style="background-color:#2a9d8f">
                        <div class="ibox-title" style="color:white"><h5>เพิ่มรายชื่อ</h5></div>
                        <div class="ibox-tools">
                            <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                        </div>
                    </div>
                    <div class="ibox-body">
                        <form class="form-horizontal" id="form-sample-1"  method="post" novalidate="novalidate" >
                        <div class="form-group row">
                          <label class="col-sm-1 col-form-label">ปีการศึกษา</label>
                                <div class="col-sm-5">
                                    <select class="form-control" style="width: 100%;" name="pstYear"required />
                                    <?php 
                                    function DateThai($strDate)
                                    {
                                    $strYear = date("Y",strtotime($strDate))+544;
                                    return "$strYear";
                                    
                                    }
                                    $strDate = date("Y");
                                        for($i = 2563 ; $i < DateThai($strDate); $i++){
                                          echo "<option>$i</option>";
                                        }
                                    
                                    ?>
                                      </select>
                                </div>

                                <label class="col-sm-1 col-form-label">ชื่อ-สกุล</label>
                                <div class="col-sm-5">
                                    <input class="form-control" type="text" name="pstName" value="<?php echo $pstName; ?>" required />
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-1 col-form-label">ดำรงตำแหน่ง</label>
                                <div class="col-sm-5">
                                    <input class="form-control" type="text" name="position" value="<?php echo $position; ?>" required />
                                </div>
                                <label class="col-sm-1 col-form-label">เบอร์โทร</label>
                                <div class="col-sm-5">
                                    <input class="form-control" id="ex-phone" type="text" name="pstPhone" value="<?php echo $pstPhone; ?>"  required />
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-1 col-form-label">องค์กร</label>
                                <div class="col-sm-5">
                                    <select class="form-control" style="width: 100%;" name="pstOrgtion"required />
                                    <option value="<?php echo $orgzerRow['orgzerOrgtion']; ?>"> <?php echo $orgzerRow['orgzerOrgtion']; ?></option>
                                    </select>
                                </div>
                                <label class="col-sm-1 col-form-label">สังกัด</label>
                                <div class="col-sm-5">
                                    <select class="form-control select2_demo_1" style="width: 100%;" name="pstOffice">
                                    <option value="<?php echo $orgzerRow['orgzerOffice']; ?>"> <?php echo $orgzerRow['orgzerOffice']; ?></option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-1 col-form-label">เพิ่มโดย</label>
                                <div class="col-sm-5">
                                    <input class="form-control" type="text" name="pstAddby" value="<?php echo $orgzerRow['orgzerName']; ?>"  readonly/>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-12 text-center">
                                    <button class="btn btn-info" type="submit" name="btaddposition">เพิ่ม</button>
                                    <button class="btn btn-danger" type="button" data-dismiss="ibox">ยกเลิก</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                    <div class="card">
                        <div class="card-header" style="background-color:#2a9d8f">
                        <h5 style="color:white" >ตารางรายชื่อตำแหน่งนักศึกษา</h5>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body pad table-responsive">
                          <table id="tbposition" class="table table-bordered table-striped text-center">
                              <thead>
                              <tr>
                              <th>ลำดับ</th> 
                              <th>ปีการศึกษา</th> 
                              <th>ชื่อ-สกุล</th>
                              <th>ดำรงตำแหน่ง</th>
                              <th>หมายเลขโทรศัพท์</th>
                              <th>เพิ่มโดย</th>
                              <th>แก้ไข</th>
                              <th>ลบ</th>
                              </tr>
                              </thead>
                              <tbody>
                              <?php
                                  require_once '../../db/dbconfig.php';
                                      $stmt = $DBcon->prepare("SELECT * FROM member ORDER BY pstID DESC");
                                      $stmt->execute();
                                  while($row=$stmt->fetch(PDO::FETCH_ASSOC))
                              {
                              ?>
                              <tr>
                              <td><?php echo $row['pstID']; ?></td>
                              <td><?php echo $row['pstYear']; ?></td>
                              <td><?php echo $row['pstName']; ?></td>
                              <td><?php echo $row['position']; ?></td>
                              <td><?php echo $row['pstPhone']; ?></td> 
                              <td><?php echo $row['pstAddby']; ?></td> 
                              <td>
                                <a class="btn btn-sm btn-warning" href="updateinfo.php?update_id=<?php echo $row['pstID']; ?>" title="click for edit" onclick="return confirm('sure to edit ?')"><span class="fa fa-edit"></span> แก้ไข</a>
                              </td>
                              <td>
                                  <a class="btn btn-danger"  href="?delete_id=<?php echo $row['pstID']; ?>"  title="click for delete" onclick="return confirm('sure to delete ?')"> <i class="fa fa-trash"></i> ลบ</a>
                              </td>
                              </tr>
                              <?php
                                }
                              ?>
                              </tbody>
                          </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    </div>
                </div>
            </div>

    <!-- BEGIN PAGA BACKDROPS-->
    <div class="sidenav-backdrop backdrop"></div>
        <div class="preloader-backdrop">
        <div class="page-preloader">Loading</div>
    </div>
    <!-- END PAGA BACKDROPS-->
    <!-- CORE PLUGINS-->
    <script src="../../assets/vendors/jquery/dist/jquery.min.js" type="text/javascript"></script>
    <script src="../../assets/vendors/popper.js/dist/umd/popper.min.js" type="text/javascript"></script>
    <script src="../../assets/vendors/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="../../assets/vendors/metisMenu/dist/metisMenu.min.js" type="text/javascript"></script>
    <script src="../../assets/vendors/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- PAGE LEVEL PLUGINS-->
    <script src="../../assets/vendors/jquery.maskedinput/dist/jquery.maskedinput.min.js" type="text/javascript"></script>
    <script src="../../assets/vendors/jquery-validation/dist/jquery.validate.min.js" type="text/javascript"></script>
    <script src="../../assets/vendors/DataTables/datatables.min.js" type="text/javascript"></script>
    <!-- CORE SCRIPTS-->
    <script src="../../assets/js/app.min.js" type="text/javascript"></script>
    <!-- PAGE LEVEL SCRIPTS-->
    <script type="text/javascript">
        $(function() {
            $('#tbposition').DataTable({
                pageLength: 10,
                //"ajax": './assets/demo/data/table_data.json',
                /*"columns": [
                    { "data": "name" },
                    { "data": "office" },
                    { "data": "extn" },
                    { "data": "start_date" },
                    { "data": "salary" }
                ]*/
            });
        })
        $('#ex-phone').mask('(999) 999-9999');
        $("#form-sample-1").validate({
            rules: {
                name: {
                    minlength: 2,
                    required: !0
                },
                email: {
                    required: !0,
                    email: !0
                },
                url: {
                    required: !0,
                    url: !0
                },
                number: {
                    required: !0,
                    number: !0
                },
                min: {
                    required: !0,
                    minlength: 3
                },
                max: {
                    required: !0,
                    maxlength: 4
                },
                password: {
                    required: !0
                },
                password_confirmation: {
                    required: !0,
                    equalTo: "#password"
                }
            },
            errorClass: "help-block error",
            highlight: function(e) {
                $(e).closest(".form-group.row").addClass("has-error")
            },
            unhighlight: function(e) {
                $(e).closest(".form-group.row").removeClass("has-error")
            },
        });

    </script>
</body>

</html>