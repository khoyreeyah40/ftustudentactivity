<?php

	error_reporting( ~E_NOTICE );


	$DB_HOST = 'localhost';
	$DB_USER = 'root';
	$DB_PASS = '';
	$DB_NAME = 'dbmyproject';
	
	try{
		$DB_con = new PDO("mysql:host={$DB_HOST};dbname={$DB_NAME}",$DB_USER,$DB_PASS);
		$DB_con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
	catch(PDOException $e){
		echo $e->getMessage();
	}
	if(isset($_GET['update_id']) && !empty($_GET['update_id']))
	{
        $id = $_GET['update_id'];
        $stmt_update = $DB_con->prepare('SELECT pstID,pstYear,pstName,position,pstPhone,pstOrgtion,pstOffice FROM member WHERE pstID=:pstid');
		$stmt_update->execute(array(':pstid'=>$id));
		$update_row = $stmt_update->fetch(PDO::FETCH_ASSOC);
		extract($update_row);
    }
    else
	{
		header("Location: position.php");
    }
    if(isset($_POST['btupdateposition']))
    {	
      $pstID = $_POST['pstID'];
      $pstYear = $_POST['pstYear'];
      $pstName = $_POST['pstName'];// user name
      $position = $_POST['position'];
      $pstPhone = $_POST['pstPhone'];
      $pstOrgtion = $_POST['pstOrgtion'];
      $pstOffice = $_POST['pstOffice'];
        // if no error occured, continue ....
        if(!isset($errMSG))
        {
          $stmt = $DB_con->prepare('UPDATE member
                                    SET 
                                    pstID=:pstID,
                                    pstYear=:pstYear,
                                    pstName=:pstName,
                                    position=:position,
                                    pstPhone=:pstPhone,
                                    pstOrgtion=:pstOrgtion,
                                    pstOffice=:pstOffice
                                    WHERE pstID=:pstID');
            $stmt->bindParam(':pstID',$pstID);
          $stmt->bindParam(':pstYear',$pstYear);
          $stmt->bindParam(':pstName',$pstName);
          $stmt->bindParam(':position',$position);
          $stmt->bindParam(':pstPhone',$pstPhone);
          $stmt->bindParam(':pstOrgtion',$pstOrgtion);
          $stmt->bindParam(':pstOffice',$pstOffice);
          if($stmt->execute()){
            ?>
            <script>
            alert('ทำการแก้ไขเรียบร้อย ...');
            window.location.href='position.php';
            </script>
            <?php
          }
          else
          {
            $errMSG = "พบข้อผิดพลาด";
          }
        }
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title>ระบบกิจกรรมนักศึกษา| แก้ไขตำแหน่งนักศึกษา</title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="../../assets/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../../assets/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
    <link href="../../assets/vendors/themify-icons/css/themify-icons.css" rel="stylesheet" />
    <!-- PLUGINS STYLES-->
    <link href="../../assets/vendors/select2/dist/css/select2.min.css" rel="stylesheet" />
    <link href="../../assets/vendors/DataTables/datatables.min.css" rel="stylesheet" />
    <link href="../../assets/vendors/jvectormap/jquery-jvectormap-2.0.3.css" rel="stylesheet" />
    <!-- THEME STYLES-->
    <link href="../../assets/css/main.min.css" rel="stylesheet" />
    <!-- PAGE LEVEL STYLES-->
    <style>
      .breadcrumb-item {
        font-size:16px;
        }
    </style>
</head>
<body class="fixed-navbar" style="background-color:#f3e9d2;">
            <div class="page-content fade-in-up"style="padding:20px;padding-top:0px">
                <div class="page-heading">
                    <h1 class="page-title">จัดการตำแหน่งนักศึกษา</h1>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                        </li>
                        <li class="breadcrumb-item"><a href="position.php">จัดการตำแหน่งนักศึกษา</a></li>
                        <li class="breadcrumb-item">แก้ไขข้อมูลตำแหน่งนักศึกษา</li>
                    </ol>
                </div>
                <br>
                <br> 
                <?php
	if(isset($errMSG)){
		?>
        <div class="alert alert-danger">
          <span class="fa fa-info-sign"></span> &nbsp; <?php echo $errMSG; ?>
        </div>
        <?php
	}
	?>
                    <div class="ibox">
                        <div class="ibox-head" style="background-color:#2a9d8f">
                            <div class="ibox-title" style="color:white"><h5>แก้ไขข้อมูลตำแหน่งนักศึกษา</h5></div>
                        </div>
                        <div class="ibox-body">
                            <form class="form-horizontal" id="form-sample-1"  method="post" novalidate="novalidate" style="height:500px; width:100%">
                                
                            <div class="form-group row">
                                <label class="col-sm-1 col-form-label">ลำดับ</label>
                                    <div class="col-sm-5">
                                        <input class="form-control" type="text" name="pstID" value="<?php echo $pstID; ?>" readonly/>
                                    </div>
                            </div>
                                    <div class="form-group row">
                                    <label class="col-sm-1 col-form-label">ปีการศึกษา</label>
                                    <div class="col-sm-5">
                                        <select class="form-control" style="width: 100%;" name="pstYear"required />
                                        <option value="<?php echo $pstYear ?>"> <?php echo $pstYear ?></option> 
                                            <?php 
                                            function DateThai($strDate)
                                            {
                                            $strYear = date("Y",strtotime($strDate))+544;
                                            return "$strYear";
                                            
                                            }
                                            $strDate = date("Y");
                                                for($i = 2563 ; $i < DateThai($strDate); $i++){
                                                echo "<option>$i</option>";
                                                }
                                            ?>
                                        </select>
                                    </div>
                                    <label class="col-sm-1 col-form-label">ชื่อ-สกุล</label>
                                    <div class="col-sm-5">
                                        <input class="form-control" type="text" name="pstName" value="<?php echo $pstName; ?>" require/>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-1 col-form-label">หมายเลขโทรศัพท์</label>
                                    <div class="col-sm-5">
                                        <input class="form-control" id="ex-phone" type="text" name="pstPhone" value="<?php echo $pstPhone; ?>"  required />
                                    </div>
                                    <label class="col-sm-1 col-form-label">ดำรงตำแหน่ง</label>
                                    <div class="col-sm-5">
                                        <input class="form-control" type="text" name="position" value="<?php echo $position; ?>" required />
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-sm-1 col-form-label">องค์กร</label>
                                    <div class="col-sm-5">
                                        <select class="form-control" style="width: 100%;" name="pstOrgtion"readonly >
                                        <option value="<?php echo $pstOrgtion; ?>"> <?php echo $pstOrgtion; ?></option>
                                        </select>
                                    </div>
                                    <label class="col-sm-1 col-form-label">สังกัด</label>
                                    <div class="col-sm-5">
                                        <select class="form-control select2_demo_1" style="width: 100%;" name="pstOffice" readonly >
                                        <option value="<?php echo $pstOffice; ?>"> <?php echo $pstOffice; ?></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12 text-center">
                                        <button class="btn btn-info" type="submit" name="btupdateposition">แก้ไข</button>
                                        <button class="btn btn-danger" type="button"><a href="organizer.php">ยกเลิก</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
            </div>
                    
    <!-- CORE PLUGINS-->
    <script src="../../assets/vendors/jquery/dist/jquery.min.js" type="text/javascript"></script>
    <script src="../../assets/vendors/popper.js/dist/umd/popper.min.js" type="text/javascript"></script>
    <script src="../../assets/vendors/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="../../assets/vendors/metisMenu/dist/metisMenu.min.js" type="text/javascript"></script>
    <script src="../../assets/vendors/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- PAGE LEVEL PLUGINS-->
    <script src=".../../assets/vendors/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
    <script src="../../assets/vendors/jquery.maskedinput/dist/jquery.maskedinput.min.js" type="text/javascript"></script>
    <script src="../../assets/vendors/jquery-validation/dist/jquery.validate.min.js" type="text/javascript"></script>
    <script src="../../assets/vendors/DataTables/datatables.min.js" type="text/javascript"></script>
    <!-- CORE SCRIPTS-->
    <script src="../../assets/js/app.min.js" type="text/javascript"></script>
    <!-- PAGE LEVEL SCRIPTS-->
    <script src="../../assets/js/scripts/form-plugins.js" type="text/javascript"></script>
    <script type="text/javascript">
    
        $(function() {
            $('#tbposition').DataTable({
                pageLength: 10,
                //"ajax": './assets/demo/data/table_data.json',
                /*"columns": [
                    { "data": "name" },
                    { "data": "office" },
                    { "data": "extn" },
                    { "data": "start_date" },
                    { "data": "salary" }
                ]*/
            });
        })
        $('#ex-phone').mask('(999) 999-9999');
        $("#form-sample-1").validate({
            rules: {
                name: {
                    minlength: 2,
                    required: !0
                },
                email: {
                    required: !0,
                    email: !0
                },
                url: {
                    required: !0,
                    url: !0
                },
                number: {
                    required: !0,
                    number: !0
                },
                min: {
                    required: !0,
                    minlength: 3
                },
                max: {
                    required: !0,
                    maxlength: 4
                },
                password: {
                    required: !0
                },
                password_confirmation: {
                    required: !0,
                    equalTo: "#password"
                }
            },
            errorClass: "help-block error",
            highlight: function(e) {
                $(e).closest(".form-group.row").addClass("has-error")
            },
            unhighlight: function(e) {
                $(e).closest(".form-group.row").removeClass("has-error")
            },
        });

    </script>
    </body>

</html>


